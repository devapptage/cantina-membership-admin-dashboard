module.exports=[51068,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=app_%28protected%29_users_layout_tsx_492268c5._.js.map