module.exports=[65521,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=app_%28protected%29_merchandise_layout_tsx_70259ba9._.js.map