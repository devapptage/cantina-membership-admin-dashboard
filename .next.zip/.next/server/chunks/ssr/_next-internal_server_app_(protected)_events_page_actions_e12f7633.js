module.exports=[98660,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_events_page_actions_e12f7633.js.map