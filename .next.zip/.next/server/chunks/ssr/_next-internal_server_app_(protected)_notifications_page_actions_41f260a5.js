module.exports=[5518,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_notifications_page_actions_41f260a5.js.map