module.exports=[21631,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=app_%28protected%29_events_loading_tsx_061373f3._.js.map