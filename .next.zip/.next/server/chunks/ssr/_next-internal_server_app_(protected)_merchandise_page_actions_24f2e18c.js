module.exports=[24222,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_merchandise_page_actions_24f2e18c.js.map