module.exports=[12498,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=app_%28auth%29_layout_tsx_2ffca1fc._.js.map