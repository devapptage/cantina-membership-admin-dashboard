module.exports=[36595,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_users_page_actions_41c1b54d.js.map