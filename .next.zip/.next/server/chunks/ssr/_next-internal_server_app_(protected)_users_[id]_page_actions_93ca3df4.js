module.exports=[1003,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_users_%5Bid%5D_page_actions_93ca3df4.js.map