module.exports=[69668,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=app_%28protected%29_notifications_loading_tsx_e0ffcab6._.js.map