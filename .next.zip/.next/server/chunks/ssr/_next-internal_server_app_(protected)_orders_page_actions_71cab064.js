module.exports=[89410,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_orders_page_actions_71cab064.js.map