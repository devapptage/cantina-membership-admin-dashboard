module.exports=[46234,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_page_actions_64427bca.js.map