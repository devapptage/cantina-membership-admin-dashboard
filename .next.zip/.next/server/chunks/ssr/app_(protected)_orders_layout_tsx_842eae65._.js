module.exports=[57771,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=app_%28protected%29_orders_layout_tsx_842eae65._.js.map