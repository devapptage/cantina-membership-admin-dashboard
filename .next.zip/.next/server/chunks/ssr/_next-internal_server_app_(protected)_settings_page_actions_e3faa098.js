module.exports=[79883,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_settings_page_actions_e3faa098.js.map