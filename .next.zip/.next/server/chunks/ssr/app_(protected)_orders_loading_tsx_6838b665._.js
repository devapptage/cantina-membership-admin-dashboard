module.exports=[65044,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=app_%28protected%29_orders_loading_tsx_6838b665._.js.map