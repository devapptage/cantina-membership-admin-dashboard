module.exports = [
"[project]/.next-internal/server/app/(protected)/notifications/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_notifications_page_actions_41f260a5.js.map