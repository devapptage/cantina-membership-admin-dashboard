module.exports = [
"[project]/.next-internal/server/app/(protected)/users/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_users_page_actions_41c1b54d.js.map