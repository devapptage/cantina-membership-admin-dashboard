module.exports = [
"[project]/.next-internal/server/app/(protected)/events/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_events_page_actions_e12f7633.js.map