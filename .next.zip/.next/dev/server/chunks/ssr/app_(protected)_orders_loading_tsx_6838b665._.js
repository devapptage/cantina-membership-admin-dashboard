module.exports = [
"[project]/app/(protected)/orders/loading.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loading
]);
function Loading() {
    return null;
}
}),
];

//# sourceMappingURL=app_%28protected%29_orders_loading_tsx_6838b665._.js.map