module.exports = [
"[project]/.next-internal/server/app/(protected)/settings/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_settings_page_actions_e3faa098.js.map