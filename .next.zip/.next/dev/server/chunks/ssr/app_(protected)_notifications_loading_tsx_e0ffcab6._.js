module.exports = [
"[project]/app/(protected)/notifications/loading.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loading
]);
function Loading() {
    return null;
}
}),
];

//# sourceMappingURL=app_%28protected%29_notifications_loading_tsx_e0ffcab6._.js.map