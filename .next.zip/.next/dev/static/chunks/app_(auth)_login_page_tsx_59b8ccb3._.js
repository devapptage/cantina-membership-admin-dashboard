(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_5fbfcd79._.js",
  "static/chunks/_5e0480dc._.js"
],
    source: "dynamic"
});
