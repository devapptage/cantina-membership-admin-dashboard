(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_9702566e._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_d6b4bf42._.js"
],
    source: "dynamic"
});
